/**
 * @author Nombre del autor
 */
public class Ejercicio1 {

    /**
     * Descripcion del algoritmo
     * @param args
     */
    public static void main(String[] args) {
        System.out.println("Hello world!");
    }
}