    /**
 * author rhcarballo
 */



public class Ejercicio6 {

    /**
     * Descripcion del algoritmo
     * 
     */
    public static void main(String[] args) {


    }
}