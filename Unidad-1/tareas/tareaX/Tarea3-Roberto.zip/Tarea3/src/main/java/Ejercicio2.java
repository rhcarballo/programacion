    /**
 * author rhcarballo
 */



public class Ejercicio2 {

    /**
     * Descripcion del algoritmo
     * 
     */
    public static void main(String[] args) {


    }
}