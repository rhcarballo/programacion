    /**
 * author rhcarballo
 */



public class Ejercicio1 {

    /**
     * Descripcion del algoritmo
     * Escribe un programa en Java que imprima el patrón siguiente:
     * 1 
     * 2 3 
     * 4 5 6 
     * 7 8 9 10 
     */
    public static void main(String[] args) {

        for (int n = 1; n <= 10; n++){
            System.out.println(n);
        }

    }
}