package ies.puerto;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

public class Ejercicio6Test{

    Ejercicio6 ejercicio6 = new Ejercicio6();


    


}

