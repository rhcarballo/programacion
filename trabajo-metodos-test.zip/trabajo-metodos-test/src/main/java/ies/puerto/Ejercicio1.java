package ies.puerto;

/**
 * Clase que tiene como objetivo realizar
 * @author
 */
public class Ejercicio1 {
    public static void main(String[] args) {

    }

    public static void metodo() {

    }

}