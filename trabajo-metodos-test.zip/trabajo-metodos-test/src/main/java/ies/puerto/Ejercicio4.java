package ies.puerto;

public class Ejercicio4 {
    public static void main(String[] args) {
        System.out.println("Hola Mundo al ejercicio X");
    }
}