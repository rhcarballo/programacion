package ies.puerto;

public class Ejercicio9 {
    public static void main(String[] args) {
        System.out.println("Hola Mundo al ejercicio X");
    }
}