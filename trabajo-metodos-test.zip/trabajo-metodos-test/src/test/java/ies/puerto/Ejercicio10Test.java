package ies.puerto;

import org.junit.jupiter.api.Test;

public class Ejercicio10Test {

    @Test
    public void testOK() {

    }
}
