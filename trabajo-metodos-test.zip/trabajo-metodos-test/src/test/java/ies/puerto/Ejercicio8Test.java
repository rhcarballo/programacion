package ies.puerto;

import org.junit.jupiter.api.Test;

public class Ejercicio8Test {

    @Test
    public void testOK() {

    }
}
