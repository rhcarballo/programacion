package ies.puerto;

import org.junit.jupiter.api.Test;

public class Ejercicio6Test {

    @Test
    public void testOK() {

    }
}
