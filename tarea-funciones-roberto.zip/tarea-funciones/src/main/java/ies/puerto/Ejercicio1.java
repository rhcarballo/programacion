package ies.puerto;

public class Ejercicio1 {
    public static void main(String[] args) {
        System.out.println("Hello world!");
    }

    public int areaTriangulo(int base, int altura) {
        int resultado = 0;
        resultado = (base*altura)/2;
        return resultado;
    }

}