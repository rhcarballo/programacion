package ies.puerto;

public class Ejercicio6 {
    public static void main(String[] args) {
    }

    public double calcularCelsius (double fahrenheit){

        double celsius = 0;
        celsius = ((5/9)*(fahrenheit-32));
         return celsius;
    }
}