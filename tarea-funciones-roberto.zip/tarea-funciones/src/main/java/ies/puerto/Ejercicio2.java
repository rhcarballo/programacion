package ies.puerto;

public class Ejercicio2 {
    public static void main(String[] args) {
        System.out.println("Hello world!");
    }
    
    public double areaCirculo(int radio) {
        double pi = 3.14;
        double resultado = 0;
        resultado = (radio*radio)*pi;
        return resultado;
    }
}