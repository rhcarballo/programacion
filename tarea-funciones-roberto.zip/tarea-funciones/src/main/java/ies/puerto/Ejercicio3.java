package ies.puerto;

public class Ejercicio3 {
    public static void main(String[] args) {
        System.out.println("Hello world!");
    }

    public int areaCuadrado(int lado) {
        int resultado = 0;
        resultado = lado*lado;
        return resultado;
    }

    public int areaRectangulo(int ladoA, int ladoB) {
        int resultado = 0;
        resultado = ladoA*ladoB;
        return resultado;
    }
}